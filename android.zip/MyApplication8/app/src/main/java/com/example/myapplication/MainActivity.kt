package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.provider.ContactsContract.CommonDataKinds.Email
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase


class MainActivity : AppCompatActivity() {
    private val databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://mobistore-704bf-default-rtdb.europe-west1.firebasedatabase.app")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val email = findViewById<EditText>(R.id.editTextTextEmailAddress)
        val password = findViewById<EditText>(R.id.editTextTextPassword)
        val loginBtn = findViewById<Button>(R.id.loginbtn)

        loginBtn.setOnClickListener {
            val emailtxt = email.text.toString()
            val passwordtxt = password.text.toString()

            if (emailtxt.isEmpty() || passwordtxt.isEmpty()) {
                Toast.makeText(this@MainActivity, "Please fill all required fields", Toast.LENGTH_SHORT).show()
            } else {
                databaseReference.child("users").addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                        if (dataSnapshot.hasChild(emailtxt)) {
                            val getPassword = dataSnapshot.child(emailtxt).child("password").getValue(String::class.java)
                            if (getPassword == passwordtxt) {
                                Toast.makeText(this@MainActivity, "Successfully login", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(this@MainActivity, "Wrong password", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            Toast.makeText(this@MainActivity, "Wrong email", Toast.LENGTH_SHORT).show()
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {}
                })
            }
        }

        val goToRegBtn = findViewById<Button>(R.id.goToRegister)
        goToRegBtn.setOnClickListener {
            val regPage = Intent(this, register::class.java)
            startActivity(regPage)
            finish()
        }
    }
}